<!DOCTYPE html>
<html>
<head>
	<title>Browser Sync Example</title>
</head>
<body>
	<?php echo "hello PHP world! :)"; ?>
</body>
</html>