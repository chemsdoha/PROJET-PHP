<!DOCTYPE html>
<html>
<head>
	<title>Browser Sync Example 02</title>
</head>
<body>
	<p><?php echo "hello PHP world :)"; ?></p>

	<a href="link.php">Link to next page</a>
	
</body>
</html>