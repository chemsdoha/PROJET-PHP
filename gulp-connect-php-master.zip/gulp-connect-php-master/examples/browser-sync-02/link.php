<!DOCTYPE html>
<html>
<head>
	<title>Browser Sync Example 02</title>
</head>
<body>
	<p><?php echo "Hopefuly we are still at browserSync proxy port 8910:))"; ?></p>

	<a href="index.php">Link to previous page</a>
	
</body>
</html>